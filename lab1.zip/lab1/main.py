from flask import Flask,request, render_template
from google.cloud import datastore
import json
import os

# Just for local test, please comment this line when deploying onto App Engine
# os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = "/Users/baichen/Desktop/JHU MSSI/Fall2020/Cloud Computing/google-cloud-sdk/appengine-token.json"
# os.environ["DATASTORE_EMULATOR_HOST"]="localhost:8081"
app = Flask(__name__, template_folder="templates")

DS = datastore.Client()

def putEvent(name, dates):
    entity = datastore.Entity(key = DS.key("event"))
    entity.update({'name':name, 'date':dates})
    DS.put(entity)
    entity.update({'name':name, 'date':dates, 'id': entity.id})
    DS.put(entity)
    # print(entity.id)
    return True
    # return entity.id

def deleteEvent(id):
    query = DS.query(kind = 'event')
    query.add_filter('id', '=', int(id))
    # query.add_filter('date', '=', dates)
    events = list(query.fetch())
    if len(events) < 1: return 0
    DS.delete(events[0].key)
    return 1

@app.route('/events')
def sendEvents():
    query = DS.query(kind = 'event')
    events = list(query.fetch())
    t = json.dumps(events)
    t = '{"events":' + t + '}'
    return t

@app.route('/event', methods = ['POST'])
def PEvent():
    t = json.loads(request.json)
    putEvent(t['name'].strip(), t['date'].strip())
    return 'OK'

@app.route('/delete', methods = ['DELETE'])
def dEvent():
    t = json.loads(request.json)
    deleteEvent(t)
    return 'Successfully Deleted'

@app.route('/')
def root():
    return render_template('index.html')


if __name__ == '__main__':
    app.run(host='127.0.0.1', port=8080, debug=True)
